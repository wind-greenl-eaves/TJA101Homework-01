package xxx;

public class CubeException extends Exception {
	
	public CubeException() {}
	
	public CubeException(String msg) {
		super(msg);
	}
}
